var themeprimary = localStorage.getItem("themeprimary") || '#1a7cbc';
var themesecondary = localStorage.getItem("themesecondary") || '#f07521';
var themesuccess = localStorage.getItem("themesuccess") || '#83C31B';
var themeinfo = localStorage.getItem("themeinfo") || '#18a0fb';
var themewarning = localStorage.getItem("themewarning") || '#FFC261';


window.Codexdmeki = {
	themeprimary: themeprimary,
	themesecondary: themesecondary,
	themesuccess: themesuccess,
	themeinfo: themeinfo,
	themewarning: themewarning,
};