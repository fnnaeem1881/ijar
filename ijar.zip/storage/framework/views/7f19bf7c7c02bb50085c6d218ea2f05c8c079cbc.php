
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH D:\smarttenantsaas-20\codecanyon-46911739-smart-tenant-property-management-system-saas\main_file\resources\views/admin/content.blade.php ENDPATH**/ ?>